
import time
import logging
import telebot

API_TOKEN = 'INSIRA_SEU_TOKEN_DO_BOT_AQUI'

bot = telebot.TeleBot(API_TOKEN)
chat_id = 'INSIRA_SEU_CHAT_ID_AQUI'

def analisar_resultados():
    # Simulação de lógica (substituir por scraping real ou API)
    import random
    escolha = random.choice(['🔴 Banker', '🔵 Player', '🟡 Empate'])
    return escolha

@bot.message_handler(commands=['start'])
def start(message):
    bot.reply_to(message, "Bot Bac Bo ativo! Enviando sinais a cada 2 minutos.")
    while True:
        sinal = analisar_resultados()
        bot.send_message(chat_id, f"Próxima aposta: {sinal}")
        time.sleep(120)

if __name__ == "__main__":
    try:
        bot.polling(none_stop=True)
    except Exception as e:
        logging.error(f"Erro no bot: {e}")
        time.sleep(10)
